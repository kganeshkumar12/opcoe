<p align="center">
  <a href="http://nestjs.com/" target="blank"><img src="https://nestjs.com/img/logo_text.svg" width="320" alt="Nest Logo" /></a>
</p>

[circleci-image]: https://img.shields.io/circleci/build/github/nestjs/nest/master?token=abc123def456
[circleci-url]: https://circleci.com/gh/nestjs/nest

  <p align="center">A progressive <a href="http://nodejs.org" target="_blank">Node.js</a> framework for building efficient and scalable server-side applications.</p>
    <p align="center">
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/v/@nestjs/core.svg" alt="NPM Version" /></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/l/@nestjs/core.svg" alt="Package License" /></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/dm/@nestjs/common.svg" alt="NPM Downloads" /></a>
<a href="https://circleci.com/gh/nestjs/nest" target="_blank"><img src="https://img.shields.io/circleci/build/github/nestjs/nest/master" alt="CircleCI" /></a>
<a href="https://coveralls.io/github/nestjs/nest?branch=master" target="_blank"><img src="https://coveralls.io/repos/github/nestjs/nest/badge.svg?branch=master#9" alt="Coverage" /></a>
<a href="https://discord.gg/G7Qnnhy" target="_blank"><img src="https://img.shields.io/badge/discord-online-brightgreen.svg" alt="Discord"/></a>
<a href="https://opencollective.com/nest#backer" target="_blank"><img src="https://opencollective.com/nest/backers/badge.svg" alt="Backers on Open Collective" /></a>
<a href="https://opencollective.com/nest#sponsor" target="_blank"><img src="https://opencollective.com/nest/sponsors/badge.svg" alt="Sponsors on Open Collective" /></a>
  <a href="https://paypal.me/kamilmysliwiec" target="_blank"><img src="https://img.shields.io/badge/Donate-PayPal-ff3f59.svg"/></a>
    <a href="https://opencollective.com/nest#sponsor"  target="_blank"><img src="https://img.shields.io/badge/Support%20us-Open%20Collective-41B883.svg" alt="Support us"></a>
  <a href="https://twitter.com/nestframework" target="_blank"><img src="https://img.shields.io/twitter/follow/nestframework.svg?style=social&label=Follow"></a>
</p>
  <!--[![Backers on Open Collective](https://opencollective.com/nest/backers/badge.svg)](https://opencollective.com/nest#backer)
  [![Sponsors on Open Collective](https://opencollective.com/nest/sponsors/badge.svg)](https://opencollective.com/nest#sponsor)-->

## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run build && func host start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Caching

Similar to the [spring-cache-reset-library](https://github.optum.com/ecp/spring-cache-reset-library), this template is added with CacheResetModule which internally uses [cache-reset-service](https://github.optum.com/ecp/cache-reset-service) to register application as a consumer under a specific topic in Azure Service Bus and also to send messages to reset the caches. For more details on the library and cache reset mechanism, refer to their respective README documentation.

#### Implementation

- To enable caching use @UseInterceptors(HttpCacheInterceptor) at controller class level to cache all the methods of the class or use it at method level to cache the response of only that particular method and use @CacheKey("<CacheName>") annotation at method/function level to give a name to that cache. All the input parameters of these methods should be annotated with @Query() annotation or with @Body() annotation. Refer to sample example in app.controller.ts
- The above caching technique is applicable only to controllers and not to resolvers.
- HttpCacheInterceptor needs to be imported from cache-reset module which is added & available within template and all other above said annotations needs to be imported from @nestjs/common framework library.

#### Configuration

- VaultKeys ECP_CACHE_RESET_CLIENTID, ECP_CACHE_RESET_CLIENTSECRET should be configured with common clientId and clientSecret during the initial setup of the project which will be used to generate jwt auth token for cache-reset-service to register consumer in azure service bus and for re-setting cache.
- Every application's instance will be subscribed/registered with its POD name (ECP_CACHE_RESET_CONSUMERNAME) under a specific topic (ECP_CACHE_RESET_TOPICNAME) in Azure service bus. "topicname" should be configured in helm files. Please reach out to ECP Core team for which topic to be used.
- Use @CacheTTL(<Seconds>) annotation to a method/function to override the default time to live seconds defined in app.module.ts
- appName in values yaml helm file will be used as serviceName (ECP_CACHE_RESET_cmcoe-backend-service-nestjs-functions) in cache-reset-service while re-setting the cache.

### Monitoring
- Please use the following documentation. https://github.optum.com/ecp/ocm-site-reliability-engineering/blob/master/SOP/monitoring/prometheus-grafana.md#how-to-instrument-nestjs-applications
  
## Support

Nest is an MIT-licensed open source project. It can grow thanks to the sponsors and support by the amazing backers. If you'd like to join them, please [read more here](https://docs.nestjs.com/support).

## Stay in touch

- Author - [Kamil Myśliwiec](https://kamilmysliwiec.com)
- Website - [https://nestjs.com](https://nestjs.com/)
- Twitter - [@nestframework](https://twitter.com/nestframework)

## License

Nest is [MIT licensed](LICENSE).
