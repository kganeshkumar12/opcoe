import { IsNotEmpty, MinLength } from 'class-validator';

export class cacheEventRequest {

    @IsNotEmpty()
    readonly cacheName: string;


    readonly cacheKey: string;

    @IsNotEmpty()
     readonly serviceName: string;


     readonly action: string;

     eventData : Map<String,String>;

    // eventTimestamp : LocalDateTime = LocalDateTime.now();
}