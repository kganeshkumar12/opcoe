import { IsNotEmpty, MinLength } from 'class-validator';

export class cacheEventResponse {


     messageStatus: string;

}