import { Controller, OnModuleInit, HttpService, OnModuleDestroy, CacheModule, HttpModule, CACHE_MANAGER } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { ServiceBusClient } from "@azure/service-bus"
import { CacheResetService } from "./cache.reset.service";
import { cacheEventRequest } from "./model/cacheEventRequest";
import { Test, TestingModule } from "@nestjs/testing";
import { CacheResetController } from "./cache.reset.controller";
import { CacheResetModule } from "./cache.reset.module";
import { GraphQLModule } from "@nestjs/graphql";
import { JwtModule } from "@nestjs/jwt";
import { GraphQLError, GraphQLFormattedError } from "graphql";
import { LoggerModule } from "nestjs-pino";
import { AuthModule } from "../../src/auth/auth.module";
import { JwtStrategy } from "../../src/auth/jwt.strategy";
import { RolesGuard } from "../../src/auth/roles.guard";
import { AuthGuard } from '../auth/auth.guard';

describe('CacheResetService', () => {
  let cache: CacheResetService;
  let configService: ConfigService;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
        imports: [
          ConfigModule.forRoot({
            isGlobal: true,
            envFilePath:['.env.local']
          }),
            AuthModule,
            HttpModule,
            CacheModule.register({
              ttl: 72000
            }),
            LoggerModule.forRoot(),
          ],
          controllers: [CacheResetController],
          providers: [ConfigService, CacheResetService,RolesGuard,JwtStrategy, AuthGuard],
    }).compile();

    cache = app.get<CacheResetService>(CacheResetService);
    configService = app.get<ConfigService>(ConfigService);
  });
  describe('root', () => {
    it('should be defined', async () => {
      const msg = {cacheKey: "test",cacheName:"test",serviceName:"Test"} as cacheEventRequest;
     await cache.processMessage(msg);
      
    });
  });

  describe('root', () => {
    it('should be defined', async () => {
      const msg = {cacheKey: "test",cacheName:"test",serviceName:"test"} as cacheEventRequest;
      await cache.processError(msg);
      
    });
  });

  describe('cachename', () => {
    it('cachename is not defined', async () => {
        const keys = ['test'];
      const msg = {serviceName:"Test"} as cacheEventRequest;
     // jest.spyOn(cache, "processMessage").mockImplementation(keys);
    await cache.processMessage(msg);
      
    });
  });

  
});
