import { CacheKey, CACHE_MANAGER, Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cache } from 'cache-manager';
import { cacheEventRequest } from './model/cacheEventRequest';

@Injectable()
export class CacheResetService {

    constructor(
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        private readonly configService: ConfigService
        ) { }

    private applicationName : string = this.configService.get<string>('ECP_CACHE_RESET_cmcoe-backend-service-nestjs-functions');

    public async processMessage(message: cacheEventRequest) {
        try {
            if (message) {
                const cacheName = message.cacheName;
                const cacheKey = message.cacheKey;
                const serviceName = message.serviceName;
 
                if (serviceName === this.applicationName && !cacheName) {
                    // clear all cache if application is present and no cache name given
                    this.clearAllCache();
                }
                else {
                    // clear specific cache base on CacheKey
                     this.evictCacheKey(message);
                    // clears everything from cache if key is empty                     
                    this.clearSpecificCache(message);
                }
            }
        }
        catch (error) {
            console.error("Cache Notification JSON Process:Error when reading value as JSON");
        }
    }

    public async processError(message: any) {
        console.error("Cache Notification Process:Error when receiving messages from namespace:{}", message.message);
    }

    private async clearAllCache() {
        console.log("Clearing all available cache from application.");
        await this.cacheManager.reset();
    }

    private async evictCacheKey(message: cacheEventRequest) {
        const isApp = await this.isApplicationCache(message);
        if (message.cacheName && isApp && message.cacheKey) {
            await this.resetCacheKey(message); //Delete specific cache key in cache name
        }
    }

    private async isApplicationCache(message: cacheEventRequest): Promise<boolean> {
        const value = await this.checkCacheName(message); //Checking whether cacheName is present or not
        if (!message.serviceName) {
            return true;
        }
        else if (message.serviceName === this.applicationName && value) {
            return true;
        }
        else {
            return false;
        }
    }

    private async clearSpecificCache(message: cacheEventRequest) {
        const isApp = await this.isApplicationCache(message);
        if (message.cacheName && isApp && !message.cacheKey) {
            await this.resetCacheName(message);  //Clear whole cache name
        }
    }

    private async resetCacheKey(message: cacheEventRequest){
        const keys: string[] = await this.cacheManager.store.keys();
        for(const key of keys){
            if (key.startsWith(message.cacheName) && key.endsWith(message.cacheKey)) {
                this.cacheManager.del(key);
                console.log(`Evict specific key from cache ${message.cacheName} and key is ${message.cacheKey} `);
            }
        }
    }

    private async resetCacheName(message: cacheEventRequest){
        const keys: string[] = await this.cacheManager.store.keys();
        for(const key of keys){
            if (key.startsWith(message.cacheName)) {
                this.cacheManager.del(key);
            }
        }
          console.log(`Clearing all mappings from cache: ${message.cacheName} `);
    }

    private async checkCacheName(message: cacheEventRequest) : Promise<boolean>{
        const keys: string[] = await this.cacheManager.store.keys();
        for(const key of keys){
            if (key.startsWith(message.cacheName)) {
                return true;
            }
        }
          return false;
    }
}