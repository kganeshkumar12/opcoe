import { CacheInterceptor, ExecutionContext, Injectable } from '@nestjs/common';
import { CACHE_KEY_METADATA } from "@nestjs/common/cache/cache.constants";

@Injectable()
export class HttpCacheInterceptor extends CacheInterceptor {

    trackBy(context: ExecutionContext): string | undefined {
        const cacheKey = this.reflector.get(
            CACHE_KEY_METADATA,
            context.getHandler(),
        );

        if (cacheKey) {
            const httpAdapter = this.httpAdapterHost.httpAdapter;
            const isHttpApp = httpAdapter && !!httpAdapter.getRequestMethod;

            const request = context.switchToHttp().getRequest();
            if (request._parsedUrl.query) {
                const parameters = request._parsedUrl.query;
                const params = parameters.split('&');
                let combineParameters: string = '';
                for (const i of params) {
                    combineParameters = combineParameters + i.substring(i.indexOf('=') + 1);
                }
                return `${cacheKey}-${combineParameters}`;
            }
            else if(JSON.stringify(request.body) != '{}') {
                return `${cacheKey}-${JSON.stringify(request.body)}`;
            }
            else {
                return `${cacheKey}-`;
            }
        }
        return super.trackBy(context);
    }


}
