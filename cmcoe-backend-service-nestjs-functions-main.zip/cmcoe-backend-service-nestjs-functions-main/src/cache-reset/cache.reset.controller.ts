import { Controller, OnModuleInit, HttpService, OnModuleDestroy } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ServiceBusClient } from "@azure/service-bus"
import { CacheResetService } from "./cache.reset.service";
import { cacheEventRequest } from "./model/cacheEventRequest";

@Controller('cache')
export class CacheResetController implements OnModuleInit, OnModuleDestroy {
    constructor(
        private readonly configService: ConfigService,
        private readonly httpService: HttpService,
        private readonly cacheService: CacheResetService,
    ) { }
    private systemName: string = this.configService.get<string>('ECP_CACHE_RESET_CONSUMER_NAME');
    private notificationBaseUrl: string = this.configService.get<string>('ECP_CACHE_RESET_SERVICEURL');
    private topicName: string = this.configService.get<string>('ECP_CACHE_RESET_TOPICNAME');
    private tokenUrl: string = this.configService.get<string>('ECP_CACHE_RESET_TOKEN_URL');
    private clientId: string = this.configService.get<string>('ECP_CACHE_RESET_CLIENTID');
    private clientSecret: string = this.configService.get<string>('ECP_CACHE_RESET_CLIENTSECRET');
    private LOG_PREFIX: string = 'ECP_CACHE_RESET';
    formattedUrl: string = "";
    receiver: any;
    onModuleDestroy() {
        console.log(`${this.LOG_PREFIX} Closing cache reset consumer`)
        this.receiver.close();
    }
    async onModuleInit() {

        if (this.topicName && this.notificationBaseUrl) {
            try {
                this.formattedUrl = this.notificationBaseUrl + "/topic/" + this.topicName + "/consumer/" + this.systemName + "/register"

                const token = await this.getAuthorizationToken();
                // Register  to the topic and start listening.
                const listenOnlyKey = await this.httpService
                    .post(
                        this.formattedUrl, {}, {
                        headers: {
                            'content-type':
                                "application/json",
                            'Authorization':
                                "Bearer " + token
                        },
                    },
                    )
                    .toPromise();
                const WebSocket1 = require("ws");
                const encodedUrl = listenOnlyKey.data.token;
                const decodedUrl = Buffer.from(encodedUrl, 'base64').toString('ascii');
                const serviceBusClient = new ServiceBusClient(decodedUrl, { webSocketOptions: { webSocket: WebSocket1, webSocketConstructorOptions: { 'TransportType': 'AmqpWebSockets' } } });

                this.receiver = serviceBusClient.createReceiver(this.topicName, this.systemName, { receiveMode: "receiveAndDelete" });

                const myMessageHandler = async (message) => {
                    const request = {
                        cacheName: message.body.cacheName,
                        cacheKey: message.body.cacheKey,
                        serviceName: message.body.serviceName
                    } as cacheEventRequest;
                    await this.cacheService.processMessage(request);
                    console.log(`message.body: ${JSON.stringify(request)}`);
                };
                const myErrorHandler = async (args) => {
                    await this.cacheService.processError(args.error);
                    console.log(
                        `Error occurred with ${args.entityPath} within ${args.fullyQualifiedNamespace}: `,
                        args.error
                    );
                };
                this.receiver.subscribe({
                    processMessage: myMessageHandler,
                    processError: myErrorHandler
                });
                console.log(` ${this.LOG_PREFIX} Cache reset notification consumer started!`);
            }
            catch (error) {
                console.warn(`${this.LOG_PREFIX} An error occurred when registering consumer with notification service, so cache notification isn't started`, error);
            }
        }
        else {
            console.log(` ${this.LOG_PREFIX} Required configuration(s) (Cache URL/Topic Name/Security) are empty, so notification consumer isn't started.`)
        }
    }

    private async getAuthorizationToken(): Promise<string> {
        try {
            if (this.clientId && this.clientSecret) {
                const tokenUrl = this.tokenUrl + "&client_id=" + this.clientId + "&client_secret=" + this.clientSecret + ""
                const dataResponse = await this.httpService
                    .post(tokenUrl)
                    .toPromise();
                const token = dataResponse.data.access_token;
                return token;
            }
            else {
                console.log(`${this.LOG_PREFIX} clientid/clientsecret is not configured to generate token.`);
            }
        }
        catch (error) {
            console.warn(`${this.LOG_PREFIX} Cache Reset Token URL: Malformed URL has error occurred.`);
        }
    }
}