import { Controller, OnModuleInit, HttpService, OnModuleDestroy, CacheModule, HttpModule } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { ServiceBusClient } from "@azure/service-bus"
import { CacheResetService } from "./cache.reset.service";
import { cacheEventRequest } from "./model/cacheEventRequest";
import { Test, TestingModule } from "@nestjs/testing";
import { CacheResetController } from "./cache.reset.controller";
import { CacheResetModule } from "./cache.reset.module";

import { AuthModule } from "../../src/auth/auth.module";
import { LoggerModule } from "nestjs-pino/dist/LoggerModule";
import { RolesGuard } from "../../src/auth/roles.guard";
import { AuthGuard } from '../auth/auth.guard';
import { JwtStrategy } from "../../src/auth/jwt.strategy";
import { of } from "rxjs";
import { AxiosResponse } from 'axios';


describe('CacheResetController', () => {
  let cache: CacheResetController;
  let cacheservice: CacheResetService;
  let httpService: HttpService;
  let configService: ConfigService;

  beforeEach(async () => {
    let app: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          isGlobal: true,
          envFilePath: ['.env.local']
        }),
        AuthModule,
        HttpModule,
        CacheModule.register({
          ttl: 72000
        }),
        CacheResetModule,
        LoggerModule.forRoot()
      ],
      controllers: [CacheResetController],
      providers: [ConfigService, CacheResetService, RolesGuard, JwtStrategy, AuthGuard],
    }).compile();

    cache = app.get<CacheResetController>(CacheResetController);
    cacheservice = app.get<CacheResetService>(CacheResetService);
    httpService = app.get<HttpService>(HttpService);
    configService = app.get<ConfigService>(ConfigService);
  });

  describe('root', () => {
    try{
    it('should be defined', async () => {
      const result: AxiosResponse = {
        data: { token: 'Test', access_token: 'Test' },
        status: 200,
        config: {},
        headers: {},
        statusText: 'OK'
      };
      jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(result));
      await cache.onModuleInit();
     //expect(await cache.onModuleDestroy()).toThrowError();
      expect(cache).toBeDefined();
    
    });
  }
  catch(error){
    console.log(error);
  }
  });
});

