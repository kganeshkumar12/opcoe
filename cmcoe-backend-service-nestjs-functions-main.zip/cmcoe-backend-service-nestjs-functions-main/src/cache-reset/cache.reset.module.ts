import { CacheModule, HttpModule, Module, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { AuthModule } from "../auth/auth.module";
import { CacheResetController } from "./cache.reset.controller";
import { CacheResetService } from "./cache.reset.service";

@Module({
  imports: [
    ConfigModule,
    AuthModule,
    HttpModule,
    CacheModule.register({
      ttl: 72000
    }),
  ],
  controllers: [CacheResetController],
  providers: [ConfigService, CacheResetService],
})
export class CacheResetModule {

}
