import { HttpModule, CacheModule, HttpService } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { JwtModule } from '@nestjs/jwt';
import { AuthGuard, PassportModule } from '@nestjs/passport';
import { Test, TestingModule } from '@nestjs/testing';
import { GraphQLError, GraphQLFormattedError } from 'graphql';
import { LoggerModule } from 'nestjs-pino';
import { AppController } from './app.controller';
import { AppModule } from './app.module';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './auth/jwt.strategy';
import { RolesGuard } from './auth/roles.guard';
import { CacheResetModule } from './cache-reset/cache.reset.module';
import { SampleResolver } from './SampleResolver';

describe('AppController', () => {
  let appController: AppController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      imports:[AppModule, LoggerModule.forRoot(),
        ConfigModule.forRoot({
          isGlobal: true,
          envFilePath:['.env.local']
        }),
        PassportModule,
        JwtModule.register({}),
        AuthModule,
        HttpModule,
        CacheModule.register({}),
        CacheResetModule ],
      controllers: [AppController],
      providers: [AppService, ConfigService, JwtStrategy, RolesGuard, SampleResolver],
    }).compile();

    appController = app.get<AppController>(AppController);
  });

  describe('root', () => {
    it('should return "Hello World!"', () => {
      expect(appController.getHello()).toBe('Hello World!');
    });
  });

  describe('root', () => {
    it('should return "check1!"', () => {
      appController.check1("Test", "Terst");
      // expect(appController.check1("Test", "Test1")).toBe({"Test", "Test1"});
    });
  });
  
});
