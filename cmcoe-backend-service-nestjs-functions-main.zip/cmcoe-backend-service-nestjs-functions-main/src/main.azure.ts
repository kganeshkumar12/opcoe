import { INestApplication, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from "nestjs-pino";
import { GlobalExceptionFilter } from 'nestjs-exceptions';
import { LoggingInterceptor } from './interceptors/logging.interceptor';

const sendInternalServerErrorCause = true;
const logAllErrors = true;

export async function createApp(): Promise<INestApplication> {
  const app = await NestFactory.create(AppModule, { logger: false });
  app.useLogger(app.get(Logger));
  app.useGlobalPipes(new ValidationPipe());
  app.useGlobalInterceptors(new LoggingInterceptor(app.get(Logger)));
  app.useGlobalFilters(new GlobalExceptionFilter(sendInternalServerErrorCause, logAllErrors));
  app.enableCors();  
  app.setGlobalPrefix('api');
  await app.init();
  return app;
}
