import { Controller, Get, Post, UseInterceptors, CacheTTL, CacheKey, Query, Body } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AppService } from './app.service';
import { HttpCacheInterceptor } from './cache-reset/http-cache.interceptor';

@UseInterceptors(HttpCacheInterceptor) /* Use this Annotation at Class level when needed to cache all the methods inside the class */
@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly configService: ConfigService) { }

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  //@UseInterceptors(HttpCacheInterceptor) /* Use this Annotation at method level when needed to cache the response of only a particular method */
  @Get('/Check1')
  @CacheKey('Check1')   /* CacheKeyName */
  @CacheTTL(60)   /* Overrides default Cache ttl defined in app.module.ts to 120 seconds */
  async check1(@Query('search') search: string, @Query('search1') search1: string): Promise<any> {
    await new Promise(r => setTimeout(r, 3000));
    return {search, search1};
  }

  @Post('/Check2')
  @CacheKey('Check2')
  async check2(@Body() search: any): Promise<string> {
    await new Promise(r => setTimeout(r, 3000));
    if (search!=null)
      return search;
  }
}