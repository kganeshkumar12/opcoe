import {
  Module,
  NestModule,
  MiddlewareConsumer,
  HttpModule,
  CacheModule,
} from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { PrometheusModule } from "@willsoto/nestjs-prometheus";

//import { GraphQLJSON } from 'graphql-type-json';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { GraphQLError, GraphQLFormattedError } from 'graphql';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './auth/jwt.strategy';
import { AuthGuard } from './auth/auth.guard';
import { RolesGuard } from './auth/roles.guard';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { CacheResetModule } from './cache-reset/cache.reset.module';
import { SampleResolver } from './SampleResolver';
import { LoggerMiddleware } from './middleware/logger.middleware';

@Module({
  imports: [
    LoggerModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      ignoreEnvFile: true,
      //envFilePath:['.env.local']
    }),
    GraphQLModule.forRoot({
      buildSchemaOptions: {
        numberScalarMode: 'integer',
      },
      //resolvers: { JSON: GraphQLJSON }, // if you need to expose a JSON as a type
      playground: true,
      installSubscriptionHandlers: false,
      context: ({ req }) => ({ req }),
      autoSchemaFile: 'schema.gql',
      useGlobalPrefix: true,
      formatError: (error: GraphQLError) => {
        const graphQLFormattedError: GraphQLFormattedError = {
          message: error.extensions.exception.response.message || error.message,
        };
        return graphQLFormattedError;
      },
    }),
    PassportModule,
    JwtModule.register({}),
    AuthModule,
    HttpModule,
    CacheModule.register({
      ttl: 72000
    }),
    CacheResetModule,
    PrometheusModule.register()
  ],
  controllers: [AppController],
  providers: [AppService, ConfigService, JwtStrategy, AuthGuard, RolesGuard, SampleResolver],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes('*');
  }
}
