import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { GqlContextType, GqlExecutionContext} from '@nestjs/graphql';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '../decorators/roles';
import * as jwt from 'jsonwebtoken';
import { EcpTokenFeilds } from './ecp.token.fields';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly logger: Logger,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const req = this.getRequest(context);
    const roles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!roles) {
      return true;
    }

    this.logger.log('roles===>' + roles);
    const roleInRequest = req.headers['x-hasura-role'];

    if (req.headers['authorization'] !== null) {
      // Getting the JSON Web Token from the authorization header.
      const jwtToken: string = req.headers.authorization;

      // Assigning JWT Token from Request header to constant bearerToken
      const bearerToken: string = jwtToken
        ? jwtToken.replace('Bearer ', '')
        : null;

      // const decoded: any = jwt.decode(bearerToken, { complete: true });
      // Verifying that the token is legitimate.

      const decodedToken: any = jwt.decode(bearerToken, {
        complete: true,
      });

      if (decodedToken) {
        const orgs: any[] =
          decodedToken.payload[EcpTokenFeilds.ECP_CLAIMS][
            EcpTokenFeilds.ECP_CLI_ORGS
          ];

        let returnFlag = false;

        orgs.forEach((org) => {
          const funcRoles: any[] = org[EcpTokenFeilds.FUNC_ROLES];

          // Iterate through all functional roles
          funcRoles.forEach((funcRole) => {
            const appRoles: string[] = funcRole[EcpTokenFeilds.APPL_ROLES];

            // Iterate through all application roles of organization
            appRoles.forEach((appRole) => {
              roles.forEach((role) => {
                if (appRole.toUpperCase() === role.toUpperCase()) {
                  returnFlag = true;
                }
              });
            });
          });
        });
        this.logger.log('returnFlag===>' + returnFlag);
        return returnFlag;
      }

      return false;
    }

    const hasRole = () => roles.includes(roleInRequest);
    const user = req.user;
    this.logger.log('user===>' + JSON.stringify(user));
    // const hasRole = () =>
    //   user.roles.some(role => !!roles.find(item => item === role));
    this.logger.log('roleInRequest===>' + roleInRequest);
    this.logger.log('hasRole===>' + hasRole());
    return roleInRequest && hasRole();

  }

  getRequest(context: ExecutionContext) {
    let req;
    if (context.getType<GqlContextType>() === 'graphql') {
      const ctx = GqlExecutionContext.create(context).getContext();
      req = ctx.req;
    } else {
      req = context.switchToHttp().getRequest<Request>();
    }
    return req;
  }
}
