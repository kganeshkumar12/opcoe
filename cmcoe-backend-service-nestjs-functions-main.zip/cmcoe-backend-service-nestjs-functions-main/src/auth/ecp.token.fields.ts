export const enum EcpTokenFeilds {
  ECP_CLAIMS = 'x-ecp-claims',
  ECP_ATTRS = 'x-ecp-attrs',
  ECP_CLI_ORGS = 'x-ecp-cli-orgs',
  ECP_TYPE = 'x-ecp-type',
  ECP_USER_ID = 'x-ecp-user-id',
  ECP_FIRST_NAME = 'x-ecp-first-name',
  ECP_LAST_NAME = 'x-ecp-last-name',
  ECP_EMAIL = 'x-ecp-email',
  ECP_SOURCE = 'x-ecp-source',
  FUNC_ROLES = 'func-roles',
  ROLE_NAME = 'role-name',
  APPL_ROLES = 'appl-roles',
}
