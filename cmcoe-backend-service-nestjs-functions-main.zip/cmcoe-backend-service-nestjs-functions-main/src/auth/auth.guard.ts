import {
  ExecutionContext,
  Injectable, Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext, GqlContextType } from '@nestjs/graphql';
import { AuthGuard as PassportAuthGuard } from '@nestjs/passport';
import { Observable } from 'rxjs';
@Injectable()
export class AuthGuard extends PassportAuthGuard('jwt') {
  constructor(
    private readonly configService: ConfigService,
    private readonly reflector: Reflector,
    private readonly logger: Logger,
  ) {
    super();
  }

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    if (context.getType<GqlContextType>() === 'graphql') {
      const ctx = GqlExecutionContext.create(context);
      if (
        ctx.getContext().req.headers['x-hasura-admin-secret'] ||
        JSON.parse(ctx.getContext().req.rawBody).operationName ===
          'IntrospectionQuery'
      ) {
        return true;
      }
    }

    if (context.getType() === 'http') {
      this.logger.log('http context');
      const req = context.switchToHttp().getRequest<Request>();
      const headers = req.headers;

      if (headers && headers['authorization']) {
        return true;
      }

      return false;
    }

    return super.canActivate(context);
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }

  public handleRequest(error: any, user: any, info: any): any {
    if (error || !user) {
      throw error || new UnauthorizedException('Token is Invalid.');
    }
    return user;
  }
}
