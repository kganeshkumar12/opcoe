const common = [
    '**/tests/features/**/*.feature',
    '--require-module ts-node/register',
    '--require **/tests/steps/**/*.ts',
    '--format progress-bar',
    '--format node_modules/cucumber-pretty'
].join(' ');

module.exports = {
    default: common
};
